# Monitor de disponibilidad — Illas Cíes (9-14 agosto)

Comprueba periódicamente si hay disponibilidad en el calendario de
[autorizacionillasatlanticas.xunta.gal](https://autorizacionillasatlanticas.xunta.gal/illasr/iniciarReserva)
para Illas Cíes / Visitantes, y te avisa por email cuando aparece
disponibilidad nueva entre el 9 y el 14 de agosto de 2026.

## ⚠️ Antes de nada: hay que verificar los selectores

Esta web es una aplicación Java/JSF antigua: no tiene URLs directas
para cada paso, todo va por clics JavaScript. Yo no he podido abrir
un navegador contra la web real para sacar los selectores exactos
(mi entorno no tiene salida a internet salvo repositorios de paquetes),
así que el script usa la mejor aproximación posible basada en el texto
visible de la página ("Illas Cíes", "Visitantes", nombres de mes, etc.)
más una detección de color verde/rojo para los días, tal y como lo
describe la propia guía oficial de la Xunta.

**Es muy probable que la primera vez algo falle o no encuentre el
calendario exactamente donde se espera.** Por eso el script tiene un
modo de diagnóstico. Sigue estos pasos:

### 1. Prueba local en modo inspección

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
playwright install chromium

python check_availability.py --inspect
```

Esto te generará una carpeta `debug/` con capturas de pantalla
(`01_home.png`, `02_after_click.png`, `03_calendar_page.png`...) y el
HTML de cada paso. Ábrelas y comprueba:

- Que `02_after_click.png` ya muestra el formulario de reserva (si
  sigue en la home, el clic sobre "Visitantes" no funcionó — mira el
  HTML para ver si hace falta aceptar algo antes).
- Que `03_calendar_page.png` muestra un calendario.

Si algo no cuadra, puedes:
- Ajustar tú mismo los selectores en `check_availability.py` (están
  todos comentados y agrupados en la sección `CONFIGURACIÓN` y en las
  funciones `go_to_calendar`, `navigate_to_month`, `classify_day_cell`).
- O pegarme el HTML de la carpeta `debug/` en el chat y te dejo los
  selectores ya corregidos.

Truco rápido para sacar selectores exactos tú mismo:

```bash
playwright codegen https://autorizacionillasatlanticas.xunta.gal/illasr/iniciarReserva
```

Esto abre un navegador donde clicas manualmente por todo el proceso
(elige Illas Cíes → Visitantes → llega al calendario) y te genera el
código Python con los selectores reales que usa Playwright — cópialos
al script.

### 2. Nota sobre el número de plazas (2 personas)

El calendario público solo muestra si el día está **verde
(disponible) o rojo (agotado)** a nivel general; no filtra por número
de plazas concretas hasta que entras a hacer la reserva. Con 2 plazas
lo normal es que si el día está en verde tengas hueco, pero en fechas
muy ajustadas de última hora podría quedar menos cupo del que
necesitas. El script te avisará en cuanto el día pase a "disponible";
la reserva definitiva la tienes que completar tú a mano y con rapidez
(recuerda que hay 2 horas para comprar el billete de la naviera una
vez conseguida la pre-reserva).

## 2. Configura el email (Gmail como ejemplo)

Si usas Gmail, crea una "contraseña de aplicación" en tu cuenta
Google (Cuenta → Seguridad → Verificación en dos pasos → Contraseñas
de aplicaciones) — no funciona con tu contraseña normal.

En tu repositorio de GitHub, ve a **Settings → Secrets and variables →
Actions → New repository secret** y crea:

| Secret        | Valor (ejemplo Gmail)     |
|---------------|----------------------------|
| `SMTP_SERVER` | `smtp.gmail.com`           |
| `SMTP_PORT`   | `587`                      |
| `SMTP_USER`   | `tucuenta@gmail.com`       |
| `SMTP_PASS`   | la contraseña de aplicación |
| `EMAIL_TO`    | email donde quieres el aviso |

## 3. Sube el proyecto a GitHub y activa Actions

```bash
git add .
git commit -m "Monitor disponibilidad Illas Cíes"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

El workflow (`.github/workflows/check-cies.yml`) se ejecuta cada 20
minutos automáticamente. También puedes lanzarlo a mano desde la
pestaña **Actions → Comprobar disponibilidad Illas Cíes → Run
workflow** (marca la casilla `inspect` si quieres correrlo en modo
diagnóstico y bajarte las capturas como artifact).

## 4. Cómo evita spam de emails

El script guarda en `state.json` (dentro del propio repo) qué días
estaban disponibles en la última comprobación, y solo envía email
cuando aparece disponibilidad **nueva** que antes no estaba. El
workflow hace commit automático de ese fichero tras cada ejecución.

## Archivos

- `check_availability.py` — script principal
- `requirements.txt` — dependencias
- `.github/workflows/check-cies.yml` — automatización
- `state.json` — se crea solo, no lo edites a mano
- `debug/` — solo se genera en modo `--inspect`
