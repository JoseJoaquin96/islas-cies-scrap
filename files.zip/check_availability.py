#!/usr/bin/env python3
"""
Monitor de disponibilidad para la reserva de autorización de visita
a las Illas Cíes (autorizacionillasatlanticas.xunta.gal).

IMPORTANTE - LÉEME ANTES DE USAR:
Esta web es una aplicación Java/JSF: casi todas las acciones (elegir
isla, tipo de visitante, pasar de mes en el calendario...) se hacen
mediante JavaScript sobre la misma URL, no hay enlaces directos a cada
paso. Esto significa que los selectores de más abajo son la mejor
aproximación posible sin poder abrir un navegador contra la web real
para inspeccionarla, y es MUY probable que algo necesite un pequeño
ajuste la primera vez que lo ejecutes.

Por eso el script tiene un modo --inspect: te guarda una captura de
pantalla y el HTML de cada paso en ./debug/ para que puedas ver
exactamente qué está pasando y ajustar los selectores si hace falta
(o pegármelos a mí para que te ayude a afinarlos).

Uso:
    python check_availability.py --inspect      # modo diagnóstico (recomendado la 1a vez)
    python check_availability.py                # modo normal (comprueba y notifica)
"""

import argparse
import json
import os
import re
import smtplib
import sys
from datetime import datetime
from email.mime.text import MIMEText
from pathlib import Path

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

BASE_URL = "https://autorizacionillasatlanticas.xunta.gal/illasr/iniciarReserva"

# ---------------------------------------------------------------------
# CONFIGURACIÓN — ajusta aquí lo que necesites
# ---------------------------------------------------------------------
ISLAND_NAME = "Illas Cíes"        # Tal cual aparece en la web
VISITOR_TYPE = "Visitantes"       # "Visitantes" | "Campistas" | "Veciños"
# nth(0) porque en el HTML "Illas Cíes" aparece antes que "Illa de Ons".
# Si en algún momento cambia el orden en la web, cambia este índice.
ISLAND_INDEX = 0

TARGET_YEAR = 2026
TARGET_MONTH = 8  # agosto
TARGET_DAYS = [9, 10, 11, 12, 13, 14]

STATE_FILE = Path("state.json")
DEBUG_DIR = Path("debug")

MESES_ES = [
    "", "enero", "febrero", "marzo", "abril", "maio", "xuño",
    "xullo", "agosto", "setembro", "outubro", "novembro", "decembro",
]
MESES_ES_ALT = [  # castellano, por si el idioma detectado es "es"
    "", "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
]


def log(msg):
    print(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}", flush=True)


def accept_cookies(page):
    """Los sitios de la Xunta suelen mostrar un banner de cookies."""
    for text in ["Aceptar", "ACEPTAR", "Aceptar todas", "Accept"]:
        try:
            btn = page.get_by_role("button", name=text)
            if btn.count() > 0:
                btn.first.click(timeout=3000)
                log(f"Cookies aceptadas (botón '{text}')")
                return
        except Exception:
            continue


def go_to_calendar(page, debug=False):
    """Navega desde la home del asistente hasta el paso con el calendario."""
    page.goto(BASE_URL, wait_until="networkidle")
    accept_cookies(page)

    if debug:
        DEBUG_DIR.mkdir(exist_ok=True)
        page.screenshot(path=str(DEBUG_DIR / "01_home.png"), full_page=True)
        (DEBUG_DIR / "01_home.html").write_text(page.content(), encoding="utf-8")

    # Todos los enlaces "Visitantes" de la página, en orden de aparición
    # (Cíes primero, Ons después, según el HTML estático de la web).
    visitantes_links = page.get_by_role("link", name=VISITOR_TYPE)
    count = visitantes_links.count()
    log(f"Encontrados {count} enlaces '{VISITOR_TYPE}' en la home")
    if count <= ISLAND_INDEX:
        raise RuntimeError(
            f"No se encontró el enlace '{VISITOR_TYPE}' nº {ISLAND_INDEX} "
            f"para '{ISLAND_NAME}'. Revisa debug/01_home.png"
        )

    visitantes_links.nth(ISLAND_INDEX).click()
    page.wait_for_load_state("networkidle")

    if debug:
        page.screenshot(path=str(DEBUG_DIR / "02_after_click.png"), full_page=True)
        (DEBUG_DIR / "02_after_click.html").write_text(page.content(), encoding="utf-8")

    # A partir de aquí puede haber un checkbox de "acepto las condiciones"
    # y un botón "Continuar" antes de llegar al calendario. Intentamos
    # cubrir ese caso sin que falle si no aparece.
    try:
        checkbox = page.locator("input[type=checkbox]").first
        if checkbox.is_visible(timeout=3000):
            checkbox.check()
            log("Checkbox de condiciones marcado")
    except Exception:
        pass

    try:
        continuar = page.get_by_role("button", name=re.compile("Continuar", re.I))
        if continuar.count() > 0 and continuar.first.is_visible(timeout=3000):
            continuar.first.click()
            page.wait_for_load_state("networkidle")
            log("Click en 'Continuar'")
    except Exception:
        pass

    if debug:
        page.screenshot(path=str(DEBUG_DIR / "03_calendar_page.png"), full_page=True)
        (DEBUG_DIR / "03_calendar_page.html").write_text(page.content(), encoding="utf-8")


def navigate_to_month(page, year, month, debug=False, max_clicks=14):
    """Avanza el calendario (con las flechas '>') hasta llegar al mes objetivo."""
    target_names = {MESES_ES[month].lower(), MESES_ES_ALT[month].lower()}

    next_button_candidates = [
        page.get_by_role("button", name=re.compile("seguinte|siguiente|next|»|›", re.I)),
        page.locator("[aria-label*='next' i]"),
        page.locator(".ui-datepicker-next"),
        page.locator("a.next, button.next"),
    ]

    for i in range(max_clicks):
        header_text = page.locator(
            ".ui-datepicker-title, .calendar-header, h2, h3"
        ).first.inner_text().strip().lower()

        if str(year) in header_text and any(name in header_text for name in target_names):
            log(f"Calendario ya en el mes objetivo: '{header_text}'")
            return True

        clicked = False
        for candidate in next_button_candidates:
            try:
                if candidate.count() > 0 and candidate.first.is_visible(timeout=1500):
                    candidate.first.click()
                    page.wait_for_timeout(600)
                    clicked = True
                    break
            except Exception:
                continue

        if not clicked:
            log("No se encontró botón para avanzar de mes; revisa el selector next_button_candidates")
            if debug:
                page.screenshot(path=str(DEBUG_DIR / "04_month_nav_fail.png"), full_page=True)
                (DEBUG_DIR / "04_month_nav_fail.html").write_text(page.content(), encoding="utf-8")
            return False

    log("Se superó el número máximo de clics buscando el mes objetivo")
    return False


def classify_day_cell(cell):
    """
    Heurística para decidir si un día del calendario está disponible.
    La guía oficial dice: verde = disponible, rojo = sin plazas.
    Se comprueban, en este orden: atributos de estado típicos,
    y como último recurso el color de fondo calculado.
    """
    try:
        class_name = (cell.get_attribute("class") or "").lower()
        aria_disabled = (cell.get_attribute("aria-disabled") or "").lower()
        title = (cell.get_attribute("title") or "").lower()
    except Exception:
        class_name, aria_disabled, title = "", "", ""

    unavailable_markers = ["disabled", "agotad", "no-dispo", "unavailable", "off", "sin-plazas"]
    available_markers = ["dispo", "available", "libre", "verde"]

    haystack = f"{class_name} {aria_disabled} {title}"
    if any(m in haystack for m in unavailable_markers):
        return False
    if any(m in haystack for m in available_markers):
        return True

    # Fallback: analizar el color de fondo calculado
    try:
        bg = cell.evaluate("el => getComputedStyle(el).backgroundColor")
        rgb = re.findall(r"\d+", bg)
        if len(rgb) >= 3:
            r, g, b = int(rgb[0]), int(rgb[1]), int(rgb[2])
            if g > r + 20 and g > b + 20:
                return True  # verdoso
            if r > g + 20 and r > b + 20:
                return False  # rojizo
    except Exception:
        pass

    # Si no se puede determinar, se asume NO disponible (opción conservadora)
    return False


def check_target_days(page, debug=False):
    """Devuelve dict {día: bool disponible} para TARGET_DAYS."""
    results = {}
    day_cells = page.locator(
        ".ui-datepicker-calendar td, .calendar-day, td[data-day], .day-cell"
    )
    total = day_cells.count()
    log(f"Celdas de día encontradas en el calendario: {total}")

    for day in TARGET_DAYS:
        # Buscamos la celda cuyo texto visible sea exactamente el número
        # de día, evitando los días "apagados" de meses adyacentes si
        # llevan alguna clase distinta (best effort).
        matching = day_cells.filter(has_text=re.compile(rf"^\s*{day}\s*$"))
        if matching.count() == 0:
            log(f"  Día {day}: no se encontró celda en el calendario")
            results[day] = None
            continue
        cell = matching.first
        available = classify_day_cell(cell)
        results[day] = available
        log(f"  Día {day}: {'DISPONIBLE' if available else 'no disponible'}")

    if debug:
        DEBUG_DIR.mkdir(exist_ok=True)
        page.screenshot(path=str(DEBUG_DIR / "05_target_month.png"), full_page=True)
        (DEBUG_DIR / "05_target_month.html").write_text(page.content(), encoding="utf-8")

    return results


def load_previous_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def send_email(subject, body):
    smtp_server = os.environ.get("SMTP_SERVER")
    smtp_port = int(os.environ.get("SMTP_PORT", "587"))
    smtp_user = os.environ.get("SMTP_USER")
    smtp_pass = os.environ.get("SMTP_PASS")
    email_to = os.environ.get("EMAIL_TO")

    if not all([smtp_server, smtp_user, smtp_pass, email_to]):
        log("Faltan variables de entorno SMTP; no se envía email. Mensaje:")
        log(body)
        return

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = smtp_user
    msg["To"] = email_to

    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(smtp_user, smtp_pass)
        server.sendmail(smtp_user, [email_to], msg.as_string())
    log(f"Email enviado a {email_to}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inspect", action="store_true",
                         help="Guarda capturas y HTML de cada paso en ./debug/")
    args = parser.parse_args()

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(locale="gl-ES")
        page = context.new_page()

        try:
            go_to_calendar(page, debug=args.inspect)
            navigate_to_month(page, TARGET_YEAR, TARGET_MONTH, debug=args.inspect)
            results = check_target_days(page, debug=args.inspect)
        except (PWTimeout, RuntimeError) as e:
            log(f"ERROR durante la navegación: {e}")
            DEBUG_DIR.mkdir(exist_ok=True)
            try:
                page.screenshot(path=str(DEBUG_DIR / "error.png"), full_page=True)
                (DEBUG_DIR / "error.html").write_text(page.content(), encoding="utf-8")
            except Exception:
                pass
            browser.close()
            sys.exit(1)

        browser.close()

    if args.inspect:
        log("Modo --inspect terminado. Revisa la carpeta ./debug/")
        return

    available_now = {str(d) for d, avail in results.items() if avail}
    prev_state = load_previous_state()
    prev_available = set(prev_state.get("available_days", []))

    new_availability = available_now - prev_available

    if new_availability:
        dates_str = ", ".join(
            f"{d}/08/{TARGET_YEAR}" for d in sorted(new_availability, key=int)
        )
        subject = f"[Illas Cíes] ¡Nueva disponibilidad! {dates_str}"
        body = (
            f"Se ha detectado disponibilidad para los siguientes días de agosto "
            f"que antes no la tenían:\n\n{dates_str}\n\n"
            f"Resultado completo de esta comprobación:\n"
            f"{json.dumps(results, indent=2, ensure_ascii=False)}\n\n"
            f"Reserva aquí: {BASE_URL}\n"
        )
        send_email(subject, body)
    else:
        log("Sin cambios respecto a la última comprobación; no se envía email.")

    save_state({
        "last_check": datetime.now().isoformat(timespec="seconds"),
        "available_days": sorted(available_now, key=int),
        "raw_results": results,
    })


if __name__ == "__main__":
    main()
